import os
from sys import path
import numpy as np
from matplotlib import pyplot as plt
from tensorflow.keras.models import load_model
import tensorflow as tf


# ------------------------------
# Absolute path to submission dir
# ------------------------------
submissions_dir = os.path.dirname(os.path.abspath(__file__))
path.append(submissions_dir)

import pickle 
import json

# ------------------------------
# Constants
# ------------------------------
EPSILON = np.finfo(float).eps


hist_analysis_dir = os.path.dirname(submissions_dir)
path.append(hist_analysis_dir)

from hist_analysis import compute_result, plot_score



# ------------------------------
# Baseline Model
# ------------------------------
class Model():
    """
    This is a model class to be submitted by the participants in their submission.

    This class should consists of the following functions
    1) init : initialize a classifier
    2) fit : can be used to train a classifier
    3) predict: predict mu_hats,  delta_mu_hat and q1,q2

    Note:   Add more methods if needed e.g. save model, load pre-trained model etc.
            It is the participant's responsibility to make sure that the submission 
            class is named "Model" and that its constructor arguments remains the same.
            The ingestion program initializes the Model class and calls fit and predict methods
    """

    def __init__(
            self,
            train_set=None,
            systematics=None
    ):
        """
        Model class constructor

        Params:
            train_set:
                labelled train set
                
            systematics:
                systematics class

        Returns:
            None
        """

        # Set class variables from parameters
        del systematics
        del train_set
        # Intialize class variables


    def fit(self):
        """
        Params:
            None

        Functionality:
            this function can be used to train a model using the train set

        Returns:
            None
        """

        self._read_model()
        self.plot_count = 2

        self.plot_file = os.path.join(submissions_dir, "Plots")
        if not os.path.exists(self.plot_file):
            os.makedirs(self.plot_file)



    def predict(self, test_set):
        """
        Params:
            None

        Functionality:
           to predict using the test sets

        Returns:
            dict with keys
                - mu_hat
                - delta_mu_hat
                - p16
                - p84
        """
        
        file_name = os.path.join(submissions_dir, 'model.keras')

        tf.config.threading.set_intra_op_parallelism_threads(1)
        tf.config.threading.set_inter_op_parallelism_threads(1)

        model = load_model(file_name)  # Load the model

        print("[*] - Testing")
        test_df = test_set['data']
        test_df = self.scaler.transform(test_df)
        test_score = model.predict(test_df).ravel()
        test_set['score'] = test_score

        print("[*] - Computing Test result")
        weights_test = test_set["weights"].copy()


        test_hist ,bins = np.histogram(test_score,
                    bins=self.bins, density=False, weights=weights_test)
        
        test_hist_control = test_hist[-self.control_bins:]

        mu_hat, mu_p16, mu_p84, alpha = compute_result(test_hist_control,self.fit_function_dict_control,SYST=True)
        delta_mu_hat = mu_p84 - mu_p16
        
        mu_p16 = mu_p16-self.calibration
        mu_p84 = mu_p84-self.calibration
        mu_hat = mu_hat-self.calibration

        if self.plot_count > 0:
            hist_fit_s = []
            hist_fit_b = []

            for i in range(self.bin_nums):
                hist_fit_s.append(self.fit_function_dict["gamma_roi"][i](alpha))
                hist_fit_b.append(self.fit_function_dict["beta_roi"][i](alpha))

            hist_fit_s = np.array(hist_fit_s)
            hist_fit_b = np.array(hist_fit_b)

            # plot_score(test_hist,hist_fit_s,hist_fit_b,mu_hat,bins,threshold=self.threshold,save_path=(self.plot_dir + f"XGB_score_{self.plot_count}.png"))

        print(f"[*] --- mu_hat: {mu_hat}")
        print(f"[*] --- delta_mu_hat: {delta_mu_hat}")
        print(f"[*] --- p16: {mu_p16}")
        print(f"[*] --- p84: {mu_p84}")

        return {
            "mu_hat": mu_hat,
            "delta_mu_hat": delta_mu_hat,
            "p16": mu_p16,
            "p84": mu_p84
        }
    

    def _read_model(self):  
        print("[*] - Intialize Baseline Model (NN bases Uncertainty Estimator Model)")

        settings_file = os.path.join(submissions_dir, "settings.pkl")
        scaler_file = os.path.join(submissions_dir, "scaler.pkl")

        settings = pickle.load(open(settings_file, "rb"))

        self.threshold = settings["threshold"]
        self.bin_nums = settings["bin_nums"]
        self.control_bins = settings["control_bins"]
        self.coef_s_list = settings["coef_s_list"]
        self.coef_b_list = settings["coef_b_list"]
        self.calibration = settings["calibration"]

        self.bins = np.linspace(0, 1, self.bin_nums + 1)

        fit_line_s_list = []
        fit_line_b_list = []

        for coef_s_,coef_b_ in zip(self.coef_s_list,self.coef_b_list):

            coef_s = np.array(coef_s_)
            coef_b = np.array(coef_b_)

            fit_line_s_list.append(np.poly1d(coef_s))
            fit_line_b_list.append(np.poly1d(coef_b))

        self.fit_function_dict = {
            "gamma_roi":fit_line_s_list,
            "beta_roi":fit_line_b_list
        }

        print(f"[*] --- length of fit_line_s_list: {len(fit_line_s_list)}")
        print(f"[*] --- length of fit_line_b_list: {len(fit_line_b_list)}")

        self.fit_function_dict_control = {
            "gamma_roi":fit_line_s_list[-self.control_bins:],
            "beta_roi":fit_line_b_list[-self.control_bins:]
        }

        self.scaler = pickle.load(open(scaler_file, 'rb'))



        